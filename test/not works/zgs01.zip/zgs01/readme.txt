this animation was made many years ago using the excellent De Luxe Paint on Amiga. The character is heavy inpired by the protagonist of Another World; one of my favorite games.
The original animation, that was in anim format, was converted it in a sequence of pictures for your convenience so it's ready to use within sdlBasic (or whatever you want to use).

I've decided to release this work, under a Creative Commons License, in the hope it could be used by someone to develop some game/demo with sdlBasic.


You can contact me at zoiba@libero.it
or visit my company web site http://www.ffx.it

---zoiba---


You are free:
  - to copy, distribute, display, and perform the work
  - to make derivative works

Under the following conditions:
  - Attribution. You must give the original author credit.
  - Noncommercial. You may not use this work for commercial purposes.
  - Share Alike. If you alter, transform, or build upon this work, you may
    distribute the resulting work only under a license identical to this one.
  - For any reuse or distribution, you must make clear to others the license terms of this work.
  - Any of these conditions can be waived if you get permission from the copyright holder.

Your fair use and other rights are in no way affected by the above.

you can read the full license terms at
http://creativecommons.org/licenses/by-nc-sa/2.0/it/legalcode
