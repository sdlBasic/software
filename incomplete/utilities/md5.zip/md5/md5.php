<?php
    printf(md5($argv[1]));
?>
