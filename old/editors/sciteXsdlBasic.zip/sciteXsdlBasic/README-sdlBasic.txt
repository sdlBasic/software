Readme SciTe for sdlBasic  20040213

this pacage is a full cross platform SciTe editor configurate with a special modify for
sdlBasic.
Scite is a very good editor for programming very efficent and small.sdlBasic source and examples demo ad run test
was totaly written with Scite

INSTALLATION WINDOWS
    unzip this pacage and copy in c:\devel\scite. if you want another path folder please
    change global option properties file in any path configuration. If there are another
    version installed please before uninstall.

    editscite.reg is a key entry for windows register. it was exported from my register.
    Warning: before install please change the path of scite.exe. 


INSTALLATION LINUX
    simple unzip in /usr/share/scite and make simbolic link from usr/share/scite/SciTe to
    /usr/bin/scite. If there are another version installed please before uninstall.

USE with sdlBasic
    simply load file sdlbas and edit with full color highsyntax for api facilities write
    the command name and (. For Help press f1


    Important:
    if you found bug or problem or suggest concerning sdlBasic configuration pleas send me a mail!!


                                                                __vroby__@libero.it
